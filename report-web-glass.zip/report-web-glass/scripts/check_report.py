#!/usr/bin/env python3
"""
报告网页的自检脚本：在部署前对生成的单文件 HTML 做静态健全性检查，
避免最常见的三类事故——首屏白屏隐患、遗留占位符、板式 class 拼错。

用法:
    python3 scripts/check_report.py <html_file>

只做静态检查，不依赖浏览器；渲染层面的验证交给 deploy skill 的 html_vision。
退出码非 0 表示有必须修复的问题。
"""
import re
import sys
import os


def main():
    if len(sys.argv) < 2:
        print("用法: python3 scripts/check_report.py <html_file>")
        return 2
    path = sys.argv[1]
    if not os.path.isfile(path):
        print(f"❌ 文件不存在: {path}")
        return 2

    with open(path, encoding="utf-8") as f:
        html = f.read()

    errors, warns = [], []

    # 1) 残留占位符（模板变量 / 板式库注释里的中文占位）
    for ph in ["__TITLE__", "__BRAND__", "__NAV_LINKS__", "__CONTENT__"]:
        if ph in html:
            errors.append(f"残留模板占位符 {ph}，未替换为真实内容")
    if "每章一个 <a" in html or "这里放下面任意板式" in html:
        errors.append("残留板式库示例注释，说明是直接拷了 component-library 没清理")

    # 2) 首屏不白屏机制必须在（否则锚点直达/截图会整屏白）
    if ".rv" in html or 'class="rv"' in html:
        if "getBoundingClientRect" not in html:
            errors.append("用了 .rv 渐显但缺少首屏判定逻辑（getBoundingClientRect），"
                          "会导致锚点直达/静态截图白屏——必须保留 base-template 的渐显 JS")
        if "pending.forEach(unhide)" not in html and "setTimeout" not in html:
            warns.append("未见渐显兜底 setTimeout，弱环境下可能有元素不显现")

    # 3) 结构完整性
    if "<title>" not in html:
        errors.append("缺少 <title>")
    if "id=\"bar\"" not in html:
        warns.append("缺少滚动进度条 #bar")
    if "id=\"nav\"" not in html:
        warns.append("缺少吸顶导航 #nav")
    if "fonts.googleapis.com" not in html:
        warns.append("未引入 Outfit/Noto Sans SC 字体，标题会退化为默认字体")

    # 4) 锚点与导航链接对应
    nav_anchors = set(re.findall(r'href="#([\w-]+)"', html))
    section_ids = set(re.findall(r'<section[^>]*\bid="([\w-]+)"', html))
    dangling = nav_anchors - section_ids - {""}
    if dangling:
        warns.append(f"导航锚点没有对应 section: {', '.join(sorted(dangling))}")

    # 5) 编造数据护栏：留个提醒（无法自动判定真伪，只做提示）
    if "占位" not in html and "待确认" not in html and "📌" not in html:
        warns.append("全文没有任何占位/待确认标记——请确认所有数字都来自材料，"
                     "缺失项应显式标注而非编造")

    print(f"检查文件: {path}  （{len(html)} 字节）")
    print("-" * 56)
    if errors:
        print(f"❌ 必须修复 {len(errors)} 项：")
        for e in errors:
            print(f"   • {e}")
    if warns:
        print(f"⚠️  建议关注 {len(warns)} 项：")
        for w in warns:
            print(f"   • {w}")
    if not errors and not warns:
        print("✅ 全部通过")
    elif not errors:
        print("✅ 无阻断问题，可部署（关注上面的建议项）")
    print("-" * 56)
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
