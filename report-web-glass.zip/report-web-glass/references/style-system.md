# 样式系统与变体

样式基座在 `assets/base-template.html` 的 `:root` 里。改风格只动 `:root` 变量，正文标记不变。

## 设计 token（默认深色版）

| token | 值 | 用途 |
|-------|-----|------|
| `--ink` | `#05070f` | 页面底色（近黑深蓝） |
| `--panel` / `--panel-2` | `rgba(255,255,255,.045/.075)` | 卡片底色 / hover |
| `--line` / `--line-2` | `rgba(255,255,255,.10/.18)` | 描边 / hover 描边 |
| `--txt` / `--txt-2` / `--txt-3` | `#e8ecf7` / `#b8c2da` / `#8290ae` | 文字三级（对比度已按 WCAG 校过，勿调更暗） |
| `--grad` | `linear-gradient(120deg,#6366f1,#a855f7,#22d3ee)` | 标题着色 / 卡片顶条 / 进度条 |
| `--indigo/violet/cyan` | `#6366f1 #a855f7 #22d3ee` | 主色系 |
| `--teal/amber/rose` | `#14b8a6 #fbbf24 #fb7185` | 语义色：已完成 / 进行中 / 风险 |

字体：标题 `Outfit`（800/900，负字距），正文 `Noto Sans SC`（300–400，行高 1.75–1.9）。

## 深色 / 浅色主题切换（一键）

模板内置两套主题，**共用同一批 token 名**，正文标记完全不用改：

- **默认深色**：`<html lang="zh-CN">`
- **浅色**：`<html lang="zh-CN" data-theme="light">` —— 只加这一个属性即可，底色、光晕、网格、导航、强调色全部自动切换。

选哪套由用户指定；用户没说时默认深色。浅色版适合正式汇报、打印、亮色环境阅读。
如果只想微调浅色观感，改 `[data-theme="light"]{}` 里的 token（在 `assets/base-template.html` 顶部）。

## 三个变体开关

改这些就够了，其余不动。

### 正式汇报版（更克制）
- 删掉 `body::after`（网格底纹）整段。
- `body::before` 只保留左上一团、透明度降到 `.10`。
- 卡片 hover 去掉 `transform:translateY`，只留 `border-color` 变化。
- 渐变只用于 `h1`/`h2`，卡片顶条 `.stat::after` 改纯色 `--line-2`。

### 换色系
只换 `--grad` 和三个主色，语义色（teal/amber/rose）保持不变：
- 暖色报告：`--grad:linear-gradient(120deg,#fbbf24,#fb7185)`
- 青绿科技：`--grad:linear-gradient(120deg,#22d3ee,#14b8a6)`

## 硬规则（踩过的坑，别改）

1. **滚动渐显必须只预隐藏首屏之外的元素**。base-template 的 JS 已实现（用 `getBoundingClientRect().top > vh*1.02` 判断 + `.pre` class + 4s 兜底）。若图省事把所有 `.rv` 初始设 `opacity:0`，分享 `#锚点` 链接或静态截图时会整屏白。
2. **`.divider` 必须写 `border:0`**——否则某些环境浏览器默认 `<hr>` 边框会叠上来。
3. **表格用 `<thead>/<th>` + `.tbl-wrap` 包裹**，不要给 `<table>` 直接设背景，圆角会裁不掉。
4. **文字别用比 `--txt-3` 更暗的颜色**，深底上会不可读。
