#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Survey data cleaning: generate "Valid Feedback" & "Low-score Feedback" sheets in the original Lark table.
问卷数据清洗：在原飞书表格里生成「有效反馈」「低分反馈」两个 sheet。

Usage (most common) / 用法（最常用）:
    python3 scripts/clean_survey.py --url "<survey table link>"

Specify columns (recommended: check the header first, then set explicitly to avoid mis-detection) /
指定列（推荐：先看表头，再显式指定，避免自动识别误判）:
    python3 scripts/clean_survey.py --url "<link>" \
        --source-sheet "原声" --score-col J --open-cols M,L --low-score 6

Preview only, no write-back / 只看清洗结果不写回:
    python3 scripts/clean_survey.py --url "<link>" --dry-run

Output / 输出:
- "Valid Feedback" sheet: removes responses whose open-ended answers have no substance
  (none / good / null / single-char etc.) / 剔除开放题无效内容的作答
- "Low-score Feedback" sheet: score <= --low-score (default 6, 10-point scale) or open-ended
  answer contains extreme negative wording / 评分 <= 阈值 或含极端负面表述的作答
Both sheets keep the original columns and column order, filtered from the original sheet (not each other).
两张表都保留原始列与列顺序，从原始 sheet（而非彼此）过滤而来。

Note / 说明: output sheet names default to Chinese ("有效反馈"/"低分反馈") for consistency with the
original tables; override with --valid-sheet-name / --low-sheet-name (e.g. "Valid Feedback").
输出 sheet 名默认中文，可用 --valid-sheet-name / --low-sheet-name 改成英文。
"""
import argparse
import csv
import io
import json
import os
import re
import subprocess
import sys

TMP_DIR = ".survey_clean_tmp"


def tmp_path(name: str) -> str:
    os.makedirs(TMP_DIR, exist_ok=True)
    return os.path.join(TMP_DIR, name)

META_HEADER_KEYWORDS = [
    "序号", "response_id", "作答时间", "提交时间", "地区", "渠道来源", "投放端",
    "操作系统", "作答语言", "sso.", "上传", "截图", "录屏", "ip", "手机", "邮箱",
    "user_id", "openid", "时长",
]

# 开放题中视为「无有效反馈」的内容（归一化后精确匹配）
INVALID_EXACT = {
    "", "无", "无无", "没有", "没", "沒有", "暂无", "暫無", "暂时没有", "暂时无", "目前没有",
    "目前无", "无了", "没有了", "无问题", "没有问题", "无建议", "暂无建议", "无意见",
    "无特别", "无特殊", "无异常", "都好", "都挺好", "都可以", "还行", "行", "可以",
    "好", "很好", "非常好", "挺好", "挺好的", "挺好用", "挺好用的", "好用", "很好用",
    "非常好用", "不错", "很不错", "满意", "很满意", "非常满意", "满足", "赞", "点赞",
    "支持", "期待", "继续加油", "加油", "感谢", "谢谢", "ok", "okay", "good", "nice",
    "great", "fine", "no", "none", "nothing", "null", "nil", "na", "n/a", "-", "--",
    "/", "//", ".", "。", "、", "，", ",", "*", "空", "略", "忽略", "跳过", "测试", "test",
    "无有效反馈", "暫無建議", "无其他", "没其他", "其他", "同上",
}

# 极端负面表述（命中即进入低分反馈）；只保留「评价性极端表述」，
# 普通问题描述（如"不准确""报错""无法使用某功能"）不算极端，避免把建设性反馈误判为低分。
NEGATIVE_PATTERNS = [
    "很差", "太差", "极差", "非常差", "特别差", "差评", "体验差", "巨差", "差得",
    "太烂", "很烂", "稀烂", "垃圾", "难用", "不好用", "很不好", "非常不好", "不太好用",
    "不友好", "反人类", "不推荐", "失望", "鸡肋", "一言难尽", "毫无用处", "完全没用",
    "根本不能用", "根本没法用", "浪费时间",
]

# 「无实质内容」的填充/纯正向词元：逐个剥离后若几乎不剩内容，则视为无效反馈
FILLER_TOKENS = [
    # 否定/无内容前缀
    "暂时还没有", "暂时没有", "目前没有问题", "没有问题", "没有其他", "无问题", "没问题",
    "暂时没", "暂时无", "暂无", "暫無", "目前没有", "目前无", "还没有", "没有了", "没有",
    "沒有", "未使用", "没用过", "未用过", "用过", "使用", "暂时", "目前", "现在", "当前",
    "已经", "还好", "还行", "没", "沒", "无", "未",
    # 纯正向/语气
    "越来越好", "特别好", "非常好", "很完善", "完善", "挺好用", "很好用", "非常好用",
    "好用", "挺好", "很好", "都挺好", "都好", "蛮好", "还不错", "很不错", "非常不错",
    "不错", "满意", "完美", "点赞", "加油", "期待", "感谢", "谢谢", "支持一下",
    "希望", "感觉", "觉得", "试用", "看看", "试试", "继续", "保持", "这个", "那个",
    "最新", "新增", "功能", "能力", "问题", "建议", "意见", "反馈", "什么", "啥",
    "我", "的", "了", "呢", "啊", "呀", "哦", "吧", "嗯", "哈", "咩", "哥", "在", "很",
    "非常", "都", "也", "就", "挺", "太", "更", "再",
    # 英文
    "allgood", "notreally", "nothingmuch", "sofargood", "verygood", "prettygood",
    "all", "good", "great", "nice", "fine", "perfect", "well", "for", "now", "not",
    "really", "much", "yet", "no", "nope", "none", "nothing", "null", "nil", "na", "ok",
    "okay", "thanks", "thx",
]

# 标点、空白、emoji、各类符号统一剔除，只留中英文数字
KEEP_RE = re.compile(r"[^0-9a-zA-Z\u4e00-\u9fff]+")


def norm(text: str) -> str:
    return KEEP_RE.sub("", (text or "").strip()).lower()


def run(args, check=True):
    proc = subprocess.run(args, capture_output=True, text=True)
    if check and proc.returncode != 0:
        sys.exit(f"命令失败: {' '.join(args)}\n{proc.stdout}\n{proc.stderr}")
    try:
        return json.loads(proc.stdout or "{}")
    except json.JSONDecodeError:
        sys.exit(f"无法解析输出: {' '.join(args)}\n{proc.stdout[:2000]}")


def col_letter_to_index(letter: str) -> int:
    idx = 0
    for ch in letter.strip().upper():
        if not ch.isalpha():
            raise ValueError(f"非法列标: {letter}")
        idx = idx * 26 + (ord(ch) - 64)
    return idx - 1


def read_sheet(url_args, sheet_id):
    """全量读取一个 sheet，返回二维 list（含表头）。"""
    tmp = tmp_path(f"sheet_{sheet_id}.json")
    run(["lark-cli", "sheets", "+csv-get", *url_args, "--sheet-id", sheet_id,
         "--include-row-prefix=false", "--output-path", tmp])
    with open(tmp, encoding="utf-8") as f:
        payload = json.load(f)
    text = payload.get("annotated_csv") or payload.get("csv") or ""
    if not text:
        data = payload.get("data") or {}
        text = data.get("annotated_csv") or data.get("csv") or ""
    rows = list(csv.reader(io.StringIO(text)))
    return [r for r in rows if any((c or "").strip() for c in r)]


def detect_score_col(header, rows):
    best = None
    for i, name in enumerate(header):
        vals = [(r[i].strip() if i < len(r) else "") for r in rows]
        vals = [v for v in vals if v]
        if not vals:
            continue
        nums = []
        for v in vals:
            try:
                nums.append(float(v))
            except ValueError:
                break
        if len(nums) != len(vals):
            continue
        if not all(0 <= n <= 10 for n in nums):
            continue
        score_hint = any(k in name for k in ["体验", "满意", "评分", "打分", "推荐", "分"])
        rank = (0 if score_hint else 1, i)
        if best is None or rank < best[0]:
            best = (rank, i)
    return best[1] if best else None


def detect_open_cols(header, rows, score_idx):
    open_cols = []
    for i, name in enumerate(header):
        if i == score_idx or not name.strip():
            continue
        if any(k.lower() in name.lower() for k in META_HEADER_KEYWORDS):
            continue
        vals = [(r[i].strip() if i < len(r) else "") for r in rows]
        vals = [v for v in vals if v]
        if not vals:
            continue
        # 单选/多选题：选项高度重复或带 " | " 分隔
        if any(" | " in v for v in vals):
            continue
        uniq_ratio = len(set(vals)) / len(vals)
        if uniq_ratio < 0.4 and len(vals) > 10:
            continue
        open_cols.append(i)
    return open_cols


def strip_fillers(n: str) -> str:
    for token in sorted(FILLER_TOKENS, key=len, reverse=True):
        n = n.replace(token, "")
    return n


def is_valid_feedback(text: str) -> bool:
    """开放题是否含有实质反馈内容。"""
    n = norm(text)
    if not n or n in INVALID_EXACT:
        return False
    if len(n) <= 1:
        return False
    if re.fullmatch(r"[a-z0-9]{1,3}", n):
        return False
    if any(p in n for p in NEGATIVE_PATTERNS):
        return True
    return len(strip_fillers(n)) >= 2


def is_negative(text: str) -> bool:
    n = norm(text)
    if not n:
        return False
    return any(p in n for p in NEGATIVE_PATTERNS)


def rows_to_csv(rows):
    buf = io.StringIO()
    csv.writer(buf, quoting=csv.QUOTE_MINIMAL, lineterminator="\n").writerows(rows)
    return buf.getvalue()


def ensure_sheet(url_args, sheets, title, col_count, row_count):
    """已存在则清空复用，否则新建；返回 sheet_id。"""
    for s in sheets:
        if s["sheet_name"] == title:
            sid = s["sheet_id"]
            run(["lark-cli", "sheets", "+cells-clear", *url_args, "--sheet-id", sid,
                 "--range", f"A1:{index_to_letter(max(s['column_count'], col_count) - 1)}"
                            f"{max(s['row_count'], row_count)}", "--target", "all"], check=False)
            return sid
    res = run(["lark-cli", "sheets", "+sheet-create", *url_args, "--title", title,
               "--col-count", str(max(col_count, 20)), "--row-count", str(max(row_count + 10, 200))])
    data = res.get("data", {})
    return (data.get("sheet") or data).get("sheet_id") or data.get("reference_id")


def index_to_letter(idx: int) -> str:
    out = ""
    idx += 1
    while idx:
        idx, rem = divmod(idx - 1, 26)
        out = chr(65 + rem) + out
    return out


def write_sheet(url_args, sheet_id, rows):
    csv_text = rows_to_csv(rows)
    path = tmp_path(f"out_{sheet_id}.csv")
    with open(path, "w", encoding="utf-8") as f:
        f.write(csv_text)
    run(["lark-cli", "sheets", "+csv-put", *url_args, "--sheet-id", sheet_id,
         "--start-cell", "A1", "--csv", f"@{path}"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", help="飞书表格链接")
    ap.add_argument("--spreadsheet-token")
    ap.add_argument("--source-sheet", help="原始问卷 sheet 名或 id；默认第一个 sheet")
    ap.add_argument("--score-col", help="评分列列标，如 J")
    ap.add_argument("--open-cols", help="开放题列列标，逗号分隔，如 M,L")
    ap.add_argument("--low-score", type=float, default=6, help="低分阈值（含），10 分制，默认 6")
    ap.add_argument("--valid-sheet-name", default="有效反馈")
    ap.add_argument("--low-sheet-name", default="低分反馈")
    ap.add_argument("--dry-run", action="store_true", help="只输出统计，不写回表格")
    args = ap.parse_args()

    if not args.url and not args.spreadsheet_token:
        sys.exit("必须提供 --url 或 --spreadsheet-token")
    url_args = ["--url", args.url] if args.url else ["--spreadsheet-token", args.spreadsheet_token]

    info = run(["lark-cli", "sheets", "+workbook-info", *url_args])
    sheets = info["data"]["sheets"]
    if args.source_sheet:
        src = next((s for s in sheets if args.source_sheet in (s["sheet_name"], s["sheet_id"])), None)
        if not src:
            sys.exit(f"未找到 sheet: {args.source_sheet}")
    else:
        src = sorted(sheets, key=lambda s: s["index"])[0]

    grid = read_sheet(url_args, src["sheet_id"])
    if len(grid) < 2:
        sys.exit("原始 sheet 数据不足")
    header, body = grid[0], grid[1:]

    score_idx = col_letter_to_index(args.score_col) if args.score_col else detect_score_col(header, body)
    if args.open_cols:
        open_idx = [col_letter_to_index(c) for c in args.open_cols.split(",") if c.strip()]
    else:
        open_idx = detect_open_cols(header, body, score_idx)
    if not open_idx:
        sys.exit("未识别到开放题列，请用 --open-cols 显式指定")

    def cell(row, i):
        return row[i].strip() if i < len(row) else ""

    valid_rows, low_rows = [], []
    for row in body:
        texts = [cell(row, i) for i in open_idx]
        if any(is_valid_feedback(t) for t in texts):
            valid_rows.append(row)
        hit_low = False
        if score_idx is not None:
            raw = cell(row, score_idx)
            try:
                if float(raw) <= args.low_score:
                    hit_low = True
            except ValueError:
                pass
        if not hit_low and any(is_negative(t) for t in texts):
            hit_low = True
        if hit_low:
            low_rows.append(row)

    print(f"原始 sheet：{src['sheet_name']}（{len(body)} 条作答）")
    print(f"评分列：{index_to_letter(score_idx) + ' ' + header[score_idx] if score_idx is not None else '未识别'}")
    print("开放题列：" + ", ".join(f"{index_to_letter(i)} {header[i]}" for i in open_idx))
    print(f"有效反馈：{len(valid_rows)} 条（剔除 {len(body) - len(valid_rows)} 条无效）")
    print(f"低分反馈：{len(low_rows)} 条（评分 <= {args.low_score:g} 或极端负面表述）")

    if args.dry_run:
        return

    ncol = max(len(header), max((len(r) for r in body), default=0))
    for title, rows in ((args.valid_sheet_name, valid_rows), (args.low_sheet_name, low_rows)):
        sid = ensure_sheet(url_args, sheets, title, ncol, len(rows) + 1)
        write_sheet(url_args, sid, [header] + rows)
        print(f"已写入 sheet「{title}」：{len(rows)} 行数据")


if __name__ == "__main__":
    main()
