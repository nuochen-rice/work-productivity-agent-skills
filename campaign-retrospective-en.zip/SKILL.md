---
name: campaign-retrospective-en
description: >-
  Generate a "Campaign & Survey Retrospective" package (bilingual EN/中文). Inputs: promo articles,
  campaign background & goals, campaign metrics, user survey feedback — any subset is fine.
  Fixed dual deliverable: (1) a structured retrospective doc filed in Lark wiki following the Oncall CLI
  framework (Key Conclusions → Basic Info → Campaign Review → User Feedback Analysis), missing fields left
  as placeholders, never fabricated; (2) a cleaned survey workbook adding "Valid Feedback" & "Low-score
  Feedback" sheets into the original table. Trigger: when the user mentions campaign/activity/survey
  retrospective, user feedback analysis, promotion/operations review, or provides a promo article /
  campaign background / metrics / user voices to organize into a retrospective. Not for generic doc
  writing, chart making, or non-retrospective reports. 自动生成「宣发 & 调研复盘」双交付（英文版，含中英文说明）：
  ①落位飞书 wiki 的结构化复盘文档 ②在原问卷表内生成「有效反馈」「低分反馈」清洗 sheet；缺失字段留占位、绝不编造。
---

# Campaign & Survey Retrospective Generator / 宣发 & 调研复盘生成

> Bilingual skill. Each section leads with English, followed by the Chinese original in a `> 中文：` quote.
> 双语 skill：每节先给英文，再用 `> 中文：` 引用附上中文原文。

## What this skill does / 这个 skill 做什么

Turn the scattered materials and data the user provides into **structurally-fixed, style-consistent** retrospective deliverables. The doc framework comes from a validated high-quality retrospective (Oncall CLI Campaign Review & User Feedback Analysis); its core value is a standardized retrospective across the triple lens of "brand exposure + feature penetration + feedback collection".

**Every run produces two deliverables** (see Step 3):
- **📊 Cleaned survey workbook** — adds "Valid Feedback" and "Low-score Feedback" sheets into the user's original survey table (script `scripts/clean_survey.py`).
- **📘 Wiki retrospective doc** — the retrospective body filed in a Lark wiki space; the title always starts with `📘 `.

Three core principles run throughout:
- **Never fabricate data**: truth is the lifeblood of a retrospective. Keep placeholders (`XX` / `(TBD)`) for missing fields and let the user fill them in; never invent numbers or user voices.
- **Guide proactively**: users rarely provide everything at once. Act like a responsible operations partner — spot gaps, ask for the key missing pieces, and flag what is still missing when delivering.
- **Dual delivery is non-negotiable**: give both the workbook (cleaning result) and the wiki doc (retrospective body); never just one of them.

> 中文：
> 把用户零散提供的素材与数据，整理成**结构固定、风格统一**的复盘交付物。文档框架源自一篇经过验证的优质复盘（Oncall CLI 宣发复盘&用户反馈分析），核心价值是"品牌曝光 + 功能渗透 + 反馈收集"三重视角的标准化复盘。
> **每次固定产出两份交付物**（详见第 3 步）：📊 问卷清洗表格（脚本 `scripts/clean_survey.py`）、📘 wiki 复盘文档（标题统一以 `📘 ` 开头）。
> 三个核心原则：不编造数据；主动引导；双交付不省。

## Step 0: Decide the branch (do this first) / 第 0 步：判断分支（最先做）

This skill has two branches. **Decide which one first**, then decide what inputs to collect:

| Branch | When | Required inputs | Output sections |
|---|---|---|---|
| **A. Survey analysis only** | User only wants to analyze survey/research results with no campaign action; or explicitly asks for "just the survey report / feedback analysis" | Survey background + survey results (scores, feedback, user voices) | A standalone survey analysis report (see `references/survey-template.xml`) |
| **B. Campaign + survey** | User has both a campaign and survey feedback; or provided promo articles / metrics etc. | All of A + promo article/assets + campaign background + campaign metrics (+ prize info) | Full campaign retrospective framework (prize consumption embedded in Campaign Review; issue-tracking appended on demand) |

When unsure, confirm in one line: "Is this **survey-result analysis only**, or a **campaign + survey retrospective**?" — proceed after it's clear.

> 中文：本 skill 有两条分支，**先判断走哪条**再决定收集哪些输入。A：仅调研分析（只分析问卷/调研结果，读 `references/survey-template.xml`）；B：宣发+调研（完整宣发复盘框架，奖品消耗嵌入宣发效果复盘，问题处理进度按需追加）。不确定时先用一句话与用户确认。

## Step 1: Collect and classify inputs (guide proactively) / 第 1 步：收集并归类输入（主动引导）

Slot existing info by branch; proactively ask for whatever is missing. Don't passively wait to be spoon-fed.

| Input category | Branch | Section | Typical content |
|---|---|---|---|
| **Survey background** | A / B | Feedback analysis intro | Purpose, time, channel, target audience, sample size |
| **Survey results / user voices** | A / B | User feedback analysis | Score distribution, NPS, feedback categories, user voices, solutions |
| **Promo article / content assets** | B | I. Basic Info (content, asset list) | Article title/link, message card, survey link, key visual |
| **Campaign background & goals** | B | I. Basic Info (table body) | Campaign time, target users, reach, promotion goals, channels |
| **Campaign metrics** | B | II. Campaign Review (2.1 Core Data) | Article UV/PV, interactions, triggers, clicks, response rate, retention, CPL |
| **Prize info** (optional) | B | II. Campaign Review (Prize Consumption) | Prize name, quantity, unit price, activity type, winners |

**Guiding rules:**
- If the user gives a Lark doc / sheet / table link → read it with `lark-doc` / `lark-sheets` / `lark-base` first, then classify; don't make the user re-paste.
- **Proactively ask for critical missing info** (missing these makes the retrospective worthless):
  - Branch A must-have: sample size + satisfaction/scores + at least some user voices.
  - Branch B additional must-have: campaign time + core metrics (at least one of UV/PV or triggers/clicks).
  - When missing, ask once: "To make the retrospective credible, I'd suggest adding [XX]. Can you provide it now? Otherwise I'll leave a placeholder."
- **Minor info need not be chased** — just leave placeholders (e.g. 7/14-day retention, winner list, article interaction details).

> 中文：按分支把已有信息归位，缺什么主动问什么。链接类先读取再归类；关键信息缺失要主动追问（A 必备样本量+评分+部分原声；B 额外必备宣发时间+核心回收数据）；次要信息直接留占位。

## Step 1.5: Clean the raw survey data (mandatory when a survey table is provided) / 第 1.5 步：问卷原始数据清洗（用户给了问卷表格就必做）

Whenever the user provides a **raw survey data table** (Lark sheet link / uploaded Excel), besides producing the retrospective doc you **must also generate cleaned sheets inside the original table**, then base the feedback analysis on the cleaned result.

**How**: run the skill's built-in script `scripts/clean_survey.py` (paths below are relative to the skill dir; use the full path when executing). Don't move data by hand.

```bash
# 1) Preview the cleaning result (no write-back) and confirm column detection
python3 scripts/clean_survey.py --url "<survey table link>" --dry-run

# 2) After confirming, write back the "Valid Feedback" and "Low-score Feedback" sheets
python3 scripts/clean_survey.py --url "<survey table link>"

# When column detection is wrong, specify explicitly (column letters follow the source sheet header)
python3 scripts/clean_survey.py --url "<link>" \
    --source-sheet "原声" --score-col J --open-cols M,L --low-score 6
```

**Output sheet structure (fixed order & names):**

| Sheet | Content | Rule |
|---|---|---|
| 1st (original, untouched) | Raw export from the survey platform | Read-only, never modified |
| **有效反馈 / Valid Feedback** | Responses after removing open-ended answers with no substance | Empty open-ended answers, or ones that only say "none / no / N/A / good / very nice / keep it up / null / ok / single char/symbol" etc. → removed; purely positive but no-ask statements also count as invalid |
| **低分反馈 / Low-score Feedback** | Negative samples that need follow-up | Score **≤ 6 (10-point scale, inclusive)**, **or** the open-ended answer contains extreme negative wording ("bad / very bad / hard to use / useless / trash / disappointed"); filtered from the **original sheet**, not re-filtered from Valid Feedback |

**Notes:**
- Both sheets **keep the original columns and column order intact** — no column added/removed, no header change — so they align with the original table for cross-checking.
- The script is idempotent: an existing sheet with the same name is cleared and reused, so you won't pile up "Valid Feedback 1 / 2".
- Scoring is unified on a 10-point scale; if the survey is 5-point, convert first or pass `--low-score 3`, and state the criterion at delivery.
- For complex surveys (non-10-point / multiple score questions / multiple open-ended questions), specify `--score-col` / `--open-cols` explicitly instead of relying on auto-detection.
- After cleaning, **use Valid Feedback for categorization & voice extraction, and Low-score Feedback for 3.3 Key Feedback Analysis**, and state the sample-size criterion in 3.1 (total received X / valid Y / low-score Z).

> 中文：只要用户提供问卷原始数据表，除了产出复盘文档，**必须在原表里生成「有效反馈」「低分反馈」两个 sheet**（脚本 `scripts/clean_survey.py`，支持 `--dry-run` 预检、`--score-col/--open-cols/--low-score` 手动指定）。有效反馈=剔除开放题无实质内容；低分反馈=评分≤6（10 分制含 6）或含极端负面表述，从原始 sheet 过滤。两 sheet 保留原始列与顺序；脚本可重复执行同名清空复用；清洗后有效反馈做分类、低分反馈做 3.3。

## Step 2: Confirm gaps with the user (lightweight, not chatty) / 第 2 步：与用户确认缺口（轻量，不啰嗦）

Briefly list "info identified" + "important items suggested to add" + "minor items to be left blank", and give the user one chance to top up:

> I've identified [campaign background + metrics]. **Suggest adding**: user voices (feedback analysis would be thin without them). **Will leave blank**: 7/14-day retention, prize details. Generate directly, or top these up first?

If the user says "just generate / I'll fill the rest", move on immediately — don't re-confirm repeatedly.

> 中文：简短列出"已识别到的信息"+"建议补充的重要项"+"将留空的次要项"，给用户一次补料机会；用户说"直接生成"就立即进入下一步。

## Step 3: Output form (fixed dual delivery) / 第 3 步：确认输出形式（固定双交付）

**Every retrospective must produce two deliverables — neither can be skipped:**

| # | Deliverable | Content | How |
|---|---|---|---|
| **①** | **Survey workbook (Excel / Lark sheet)** | Generate "Valid Feedback" and "Low-score Feedback" cleaned sheets inside the user's original survey table | `scripts/clean_survey.py` from Step 1.5; if the user gave a local Excel, import it first with `lark-cli sheets +workbook-import`, then clean |
| **②** | **Lark wiki doc** | The full retrospective doc, **must be filed in a wiki space** (not a loose docx in personal Drive) | Step 4: generate content with `lark-doc` + file into wiki with `lark-cli wiki` |

- If the user provided no raw survey table → ① may be skipped, but say so at delivery ("no raw survey data this time, so no cleaned workbook").
- If the user also wants an "IM-pasteable text version" → **append** a condensed Markdown overview (key conclusions + key data + top feedback) **in addition to** the dual delivery; it cannot replace ②.

> 中文：**每次复盘必须产出两份交付物**：①问卷表格（原表内生成两个清洗 sheet；本地 Excel 先 `sheets +workbook-import` 导入再清洗）②飞书 wiki 文档（必须落 wiki 空间）。没问卷原表时①可省略但需说明；要文字版时在双交付之外追加，不能替代②。

## Step 4: Fill the template and produce / 第 4 步：填充模板并产出

**(Optional) condensed text overview**: organize as "key conclusions → key data → key feedback categories → to-be-filled note"; concise, no full XML template needed.

**Lark wiki doc (mandatory):**
1. **Pick and read the template** (with the Read tool):
   - Branch A (survey only) → read `references/survey-template.xml` (standalone survey report skeleton).
   - Branch B (campaign + survey) → read `references/template.xml` (campaign retrospective skeleton from the latest Oncall CLI doc).
2. **Set the title**: **all doc titles start with `📘 `** (emoji + half-width space), never omit it.
   - Branch A → `📘 <Topic> User Satisfaction Survey Report` (**no period prefix like Y2026H1**, keep only the topic).
   - Branch B → `📘 Campaign Review & User Feedback Analysis | <Campaign Name>`
3. **Fill in**: place the user's data item by item. **Strictly keep the section structure and callout/table/grid layout** — that's the template's core value.
   - The **Evaluation Criteria block is copied verbatim** from the "Volcengine Console User Satisfaction Survey Report" (satisfaction / usability / NPS three dimensions and tier standards), already built into the template — don't rewrite the criteria.
   - **Voice details must be one-per-line + attributed**: each voice on its own line (`<br/>` or separate `<p>`), format `"voice content" — username`; never cram multiple voices on one line, so each can be followed up.
4. **Placeholder rules**:
   - Missing number → fill `XX` (e.g. reuse rate `XX%`).
   - Missing whole section → keep title & table skeleton, put `(TBD)` in cells.
   - Sentences in the top conclusion callout that involve missing data also use `XX` — never invent numbers.
5. **Top "to-be-filled" note**: when critical items are genuinely missing, insert a `<callout emoji="⚠️">` after the conclusion callout and before the body, listing the fields left blank; if materials are already complete, omit this note to keep the doc clean.
6. **Generate and file into wiki** (two steps — don't stop at the first):

   ```bash
   # 6.1 Resolve the wiki location: if the user gave a wiki link, parse space_id / node_token
   lark-cli wiki +node-get --url "<the wiki link from the user>"

   # 6.2 Create the doc content (XML)
   lark-cli docs +create --as user --content @retro.xml

   # 6.3 Move the docx into wiki (obj-token = the document_id returned in 6.2)
   lark-cli wiki +move --obj-type docx --obj-token "<document_id>" \
       --target-space-id "<space_id>" --target-parent-token "<parent node_token; omit to land at space root>"
   ```

   - **Reverse order also works**: first `lark-cli wiki +node-create --space-id <space_id> --parent-node-token <node> --obj-type docx --title "📘 ..."` to create an empty node, then `docs +update --command append` to write content into the returned `obj_token`. Either is fine; the former is more reliable.
   - **When the user didn't specify a wiki location**: ask once — "Which wiki space / parent node should this go under? A wiki link is enough." If the user says "anywhere / put it in mine" → use `--target-space-id my_library` (personal library).
   - After moving into wiki, **read back to confirm**: `lark-cli wiki +node-get --obj-token <document_id>`, then deliver with the wiki link (prefer the wiki link over the raw docx link).

> 中文：可选文字概览；wiki 文档必产出。选模板→定标题（统一 📘 开头）→填空（保结构、评估标准照搬、原声分行标注用户名）→占位规则（XX / （待补充））→顶部待补充提示（可省）→生成并落位 wiki（`wiki +node-get` 解析位置 → `docs +create` → `wiki +move --obj-type docx` 移入 → 回读拿 wiki 链接）。用户没指定位置先问一句，说随便就用 `my_library`。

## Step 5: Deliver / 第 5 步：交付

**Always give two links + one criterion note:**

1. **📊 Survey workbook link** — state "total received X / valid feedback Y (removed Z invalid) / low-score W", so the user can verify the cleaning result directly; if a score column/threshold was manually specified during cleaning, state that too.
2. **📘 Wiki doc link** — note in one line which placeholders (`XX` / `(TBD)`) need to be filled; re-flag any important "suggested to add" items.

(Optional) If the user wants a text version, append a condensed overview.

> 中文：固定给两个链接 + 口径说明：①问卷表格链接（总回收/有效（剔除多少）/低分）②wiki 文档链接（提示待补占位符）。可选附文字概览。

## Template structure (must keep) / 模板结构（务必保持）

This skill has **two independent templates**, chosen by branch:

### Branch B: Campaign retrospective template (`references/template.xml`)

Key Conclusions + three body sections, order not changeable (prize consumption is embedded inside "II. Campaign Review", not a standalone chapter):

1. **Key Conclusions** (top callout) — triple-value summary + key numbers + open issues, 2-4 bullets
2. **I. Basic Info** — 6-column table (content/time/target users/reach/goals/channels) + asset-list grid (left callout lists asset links, right image placeholder)
3. **II. Campaign Review**
   - 2.1 Core Data — ① goal-achievement overview table (metric/target/actual/rate/note, keep when targets exist) ② per-channel table (channel/reach/clicks/CTR, keep for multi-channel) ③ full metric detail: 3-column table grouped by "exposure/conversion/feedback/retention/cost"
   - **Prize Consumption** — right after core data, 6-column table (prize/qty/unit price/total/activity type/winner) + CPL total, plus a 🎁 "prize conclusion" callout at the end
   - 2.2 Effect Analysis — three callouts: Highlights (💡) / Improvements (🌟) / Thoughts for next time (💭)
4. **III. User Feedback Analysis**
   - 3.1 Satisfaction Overview — score distribution + Promoter/Passive/Detractor NPS table + usage-scenario table
   - 3.2 Feedback Category Overview — 4-column table: category/count/share/summary
   - 3.3 Key Feedback Analysis — 5-column table: category(with count)/priority/description(phenomenon+root cause)/solution/user voices; key issues must state "phenomenon → root cause → action"
   - 3.4 Issue Handling Progress (optional) — 7-column table: category/request/current action/priority/owner/status/ETA; omit the whole section when there's no data

### Branch A: Survey analysis report template (`references/survey-template.xml`)

Modeled on the Volcengine Console satisfaction survey report, five chapters:

1. **Key Conclusions** (top callout 💡) — survey/source data links + NPS/satisfaction/usability vs. last period + by-role/by-business findings
2. **I. Survey Overview** — background & purpose / respondents / time & method / evaluation criteria (with metric-dimension table)
3. **II. Survey Results**
   - 2.1 Overall — overview + NPS/satisfaction comparison table + by-role + regional satisfaction
   - 2.2 Platform sub-modules — per-module NPS/satisfaction/TOP3 feedback table
   - 2.3 Open-ended feedback — positive/negative/neutral 3-way table
4. **III. Voices & Key Issues ⚠️** — per-module issue table / general issue table / other-component follow-up table + positive voice reference
5. **IV. Follow-up Focus** (callout 🌟) + **V. Appendix**

Both templates mark every replaceable spot with `{{placeholders}}`; missing fields keep `XX` / `(TBD)` per the placeholder rules.

> 中文：两套独立模板按分支选用。分支 B（`references/template.xml`）：重点结论 + 三大正文章节（奖品消耗嵌在二、宣发效果复盘内，不独立成章）。分支 A（`references/survey-template.xml`）：参考字节云大官网满意度调研报告，五大章节。占位符统一标注，缺失字段留 XX / （待补充）。

## Core principles / 重要原则

- **Never fabricate data**: leave `XX` / `(TBD)` for what's missing — better empty than false.
- **Guide proactively**: spot gaps → ask for key info → flag TBDs at delivery; be the user's retrospective partner, not a passive form-filler.
- **Clear branching**: decide A/B first, then collect matching inputs; don't ask a "survey-only" user for campaign metrics.
- **Keep structure**: section order & hierarchy, table column counts, and callout emojis all come from a validated high-quality template — don't arbitrarily delete/merge them; in particular, don't split "Prize Consumption" back into a standalone chapter.
- **Dual delivery is non-negotiable**: always give both "cleaned survey workbook + wiki retrospective doc"; the doc must be filed in wiki, never just a Drive docx link.
- **Voice fidelity**: for voices with names, prefer `<cite type="user" user-id="..." user-name="...">`; without a real ID, use plain-text name — don't invent an ID.
- **Charts / dashboards**: put the user's dashboard/data links in verbatim; don't self-make charts.
- **Language**: match the user's input language (default Chinese for zh users, English for en users).

> 中文：不编造数据；主动引导；分支清晰；保结构（尤其不要把奖品消耗拆回独立章节）；双交付不可省（文档必须落 wiki）；用户原声保真；图表/看板原样放入；语言与用户输入一致。
