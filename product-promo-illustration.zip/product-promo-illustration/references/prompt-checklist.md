# Prompt Assembly and Iteration Checklist

## Assembly Order

Organize the prompt in the following order, leaving nothing out:

1. **Usage and ratio**: landscape / ultra-wide banner, target aspect ratio and safe margins.
2. **Style and material**: clay 3D or flat vector; character tier (business / tech staff), attire, expression.
3. **Composition zoning**: template (three-panel / left-right / horizontal three-stage / stacked two-section / text-left image-right), number of cards and spacing.
4. **Per-panel scene**: character action, what they face, icons / interface elements, emotional state.
5. **Icons and symbols**: rounded-square icons, circular nodes, question marks, @, arrows (solid = progression; winding dashed = clutter).
6. **Copy list**: item by item, wrapped in quotation marks; mark hierarchy (main title / subtitle / small print / label), color, and position.
7. **Background and palette**: flat base color, brand-blue accent, restrained use of semantic colors.
8. **Exclusions**: no pseudo-text or garbled characters, no watermark, no fake logo, no QR code, no unapproved numbers or prizes.
9. **Reference-image inheritance**: image 1 / image 2 numbering; state the inheritance scope (style / identity / layout) and exclusion scope for each.

## Reference-Image Inheritance Rules

- **New image**: use `image_gen` when there is no identity master; baseline images in `assets/` may inform material and palette, but do not copy their specific copy.
- **Inherit style / layout**: pass the prior deliverable into `image_edit`, state that characters, palette, and rounded corners are carried over, and exclude old copy and old elements.
- **Identity-sensitive elements** (brand logo, established IP): the confirmed actual image must be passed in; a text resemblance cannot substitute for identity reference.
- **Page screenshots**: contribute structural elements only; strip interference per the desensitization checklist in style-copy.md.
- For multi-image input, keep the "image 1, image 2" order fixed in the prompt, matching the actual input order.

## Local Iteration Actions

Reuse the baseline in `image_edit`, change only the authorized scope, keep everything else as-is:

- Change background: pure white / very pale blue / specified color value, flat with no gradient.
- Change on-image copy: fix typos, replace labels; keep original position, size, and selected state.
- Add / remove arrows, bubbles, decorative elements; add or remove cards.
- Differentiate card tints: different capability cards use different light tints (pale blue / pale cyan-gray).
- Attach brand logo: pass the actual image per session; keep the ring / wordmark shape unchanged.
- Adjust whitespace: pull everything inward, widen margins, do not touch the edge.
- Adjust left-right proportion, spacing between text group and interface card.
- Series extension: follow the master's ratio, palette, character material, and rounded-corner language.

## Production Notes

- Pure-image results are delivered as generated; do not proactively QA and regenerate. Iterate per the list above after user feedback.
- Produce series images separately; unify palette, characters, and templates within the same brief; do not overwrite each other's baselines.
- When a long image exceeds the 16:9 height/width threshold, follow the segmentation rules of the image-production skill.
