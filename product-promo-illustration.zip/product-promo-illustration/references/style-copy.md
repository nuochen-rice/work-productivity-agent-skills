# Style, Palette, and Copy Boundaries

## Character Styles

### Clay business person (default)
- 3D clay / soft-pottery Q-version characters, rounded heads, simplified limbs, friendly expressions.
- Blue suit + white shirt + tie (female equivalent in a matching suit), brand blue as the primary color.
- Pain side: confused expressions such as frowning, scratching the head, spreading hands; benefit side: smiling, raising a hand to present, relaxed posture.

### Tech staff (optional tier)
- Research / engineer workwear look, clean and appropriate, de-emphasizing formal business attire.
- Suits technical platforms and engineering-tool products; switch when the user specifies.

### Count and setting
- Default 1–3 people; parallel pain points may use one person per panel; comparisons may use one on each side.
- When the presence of people is unspecified, product-interface explainers may show only interface cards + icons.

## Style Tiers

- **Clay 3D**: default, soft-pottery material + soft shadows + rounded cards.
- **Flat vector**: first-class alternative; flat color blocks, no 3D volume or clay texture; use when the user explicitly asks for a clean vector look.
- Do not mix the two tiers within one image; series images keep material, scale, and rounded-corner language consistent.

## Palette

- Default blue-and-white: light white / very pale blue background (a near-white pale blue, flat) + brand-blue accents + dark-gray body copy.
- Semantic colors:
  - Red: pain point, alert, blocked state, small-area accent only.
  - Blue-green: positive outcome, success state.
  - Gray: secondary information, unselected state, auxiliary elements.
- Stay within adjacent hues in one image; avoid jumping colors. Do not use large-area purple, gold, or red-gold celebratory palettes.
- Flat background; no gray gradients, halos, confetti, stage spotlights, or volumetric light.

## Typography Hierarchy

1. Main title: bold, brand blue, largest size.
2. Subtitle: dark gray, secondary size.
3. Small print / English: gray, smallest size.
4. Scene label: short label inside the card, legible at thumbnail size.

- Comic images carry scene labels only; do not stack section headings. Headers may carry main/sub titles and small print.
- List on-image copy item by item and wrap quoted copy in quotation marks; describe typeface character only, do not promise a specific font family.
- No pseudo-text, garbled characters, fake logos, or dummy text stuffed into long empty bubbles.

## Language Rules

- No English small-print by default; on-image language is specified by the user: Chinese / English / bilingual.
- Defaults to Chinese when unspecified.
- In bilingual output, Chinese is primary and English is auxiliary small print, never dominating.

## Material Handling

- Product page screenshots contribute structure and elements only (tabs, input fields, buttons, entry cards, icons).
- Strip out: long announcement text, user avatars, nicknames, chat links, red-dot badges, CLI wording, screenshot watermarks, personal identifiers.
- Prior deliverables are inherited as style / layout baselines; the brand logo must be supplied as an actual image per session, not redrawn from a text description, and is not bundled in this skill's assets.
- Reference images are referred to in the prompt as "image 1, image 2" in order; state what each image contributes and what is excluded.

## Fact Boundaries (must not be broken in image or copy)

- Do not promise second-level resolution, guaranteed reach to a human, a single bot for the whole group, or automatic confirmation.
- AI replies are for reference only; key conclusions must be confirmed with a human; the official assistant does not replace human business responsibility.
- Do not include unapproved amounts, quotas, dates, prizes, QR codes, or fabricated statistics.
- Feedback screenshots / examples must be desensitized; scenarios without an integrated capability still need to contact the on-call person in the group.

## Exclusion Checklist

- Fake logos, fake brand wordmarks, watermarks, signatures.
- QR codes, prize images, countdowns, unreleased campaign information.
- Celebratory light effects, radial backgrounds, large color-block gradients.
- Real-person portraits or third-party brand marks unrelated to the product.
