# Layout and Composition Templates

## Default Ratios

| Usage | Default ratio | Reference pixels | Notes |
|---|---|---|---|
| In-article comic | 16:9 landscape | ~2730×1536 | Paneled narrative, embedded in document body |
| Card image | 4:3 | Rounded to tool-supported range | Feature cards, capability explanations |
| Wiki / document header | 5:1 ultra-wide | ~2500×500 | Text-left, image-right; generous whitespace around |
| Banner | 3:1 | Rounded to tool-supported range | Top banner, promo slot |
| Other | Custom aspect ratio and pixels | — | Overrides default when explicitly specified |

Landscape figures keep a safe margin on all sides; headers leave ample whitespace on left/right and top/bottom, with elements not touching the edge.

## Composition Templates

Choose a template by the copy structure; series images share a consistent rounded-corner language and card spacing.

### 1. Three-panel side by side
- Structure: three equal-width rounded cards in a row, each with one scene and a short label.
- Use: multiple parallel pain points, or multiple parallel capabilities.
- Notes: character material, scale, and palette are consistent across the three; labels remain legible at small size; even spacing between panels.

### 2. Left-right comparison (before / after)
- Structure: confused pain-point scene on the left, an arrow in the middle, a clear benefit / interface card on the right.
- Use: before-and-after contrast of problem → solution.
- Notes: arrow points left to right; the two cards may use different light tints to distinguish them; pain side looks puzzled, benefit side looks relaxed.

### 3. Horizontal three-stage
- Structure: pain point → platform action → actual benefit, three horizontal columns joined by arrows.
- Use: full-journey narrative where the middle action stage must be shown.

### 4. Two stacked sections
- Structure: pain-point panels on top, benefit panels below, optionally split by section tint.
- Use: long comic where pain points and benefits are symmetric in count and need vertical layering.

### 5. Text-left, image-right (header)
- Structure: logo (supplied per session) + main title + subtitle + optional small print on the left; an acrylic / interface card or product scene on the right.
- Use: wiki header, promo banner.
- Notes: the text group and right image are pulled toward the middle with surrounding whitespace; hierarchy main title > subtitle > small print.

## Template Selection Tips

- Copy lists parallel problems → three-panel side by side.
- Copy is a before/after contrast → left-right comparison.
- Copy includes a middle action stage → horizontal three-stage or two stacked sections.
- Copy is an opening banner → text-left, image-right.
- For a multi-image series, fix one master first; the rest follow its ratio, palette, characters, and rounded corners.
