---
name: product-promo-illustration
description: Produce a cohesive set of bitmap illustrations for product, internal tool, and platform promotion: comic-style in-article graphics, pain-point / capability-benefit visuals, wiki document headers, and card images. Distill pain point, platform action, and benefit narratives from a PRD, product page screenshot, or background document. Defaults to a blue-and-white palette and clay-style 3D business characters, with a flat-vector alternative; supports consistent series styling and localized iteration. Use when the user asks for promo comics, in-document figures, header images, card posters, before/after comparisons, or to recolor, reword, rearrange, or restyle an existing deliverable.
---

# Product Promo Illustration

## Overview

Turn a piece of product copy (pain point → platform action → benefit) into a cohesive set of bitmap illustrations ready to drop into documents, group cards, or pages. Default to pure-image production: `image_gen` for new images, `image_edit` to inherit a baseline for localized edits. Deliver generated images immediately; do not run a self-check and regenerate a finished output.

## Input Slots

| Slot | Description | Required |
|---|---|---|
| Topic copy | Pain points, actions, and benefits to depict, or the corresponding document passage | Yes |
| Usage / layout | Article comic, card image, wiki header, or banner; determines the default ratio | Yes |
| Reference materials | PRD, product page screenshot, prior deliverable, baseline comic; the brand logo is supplied per session and is not bundled in this skill | No |
| On-image copy | Main/sub titles, labels, small-print text, slogan list; otherwise distilled from the copy | No |
| Custom dimensions | Aspect ratio / pixel size, overriding the default ratio | No |
| Style overrides | Special requests for characters, palette, background, presence of people, etc. | No |

## Default Parameters (all overridable by input)

- **Ratio**: article comic 16:9; card image 4:3; wiki/document header 5:1; banner 3:1; otherwise custom. See [references/layout-templates.md](references/layout-templates.md).
- **Characters**: default clay business person (3D soft-clay Q-version, blue suit, rounded head); optional tech-staff persona. See [references/style-copy.md](references/style-copy.md).
- **Style tier**: clay 3D primary; flat vector as a first-class alternative.
- **Palette**: default blue-and-white, light white / very pale blue background + brand-blue accents + dark-gray body copy; semantic colors limited to red = pain point, blue-green = positive outcome, gray = secondary.
- **Language**: no English small-print by default; on-image language is specified by the user (Chinese / English / bilingual). Defaults to Chinese when unspecified.

## Workflow

1. **Clarify content and layout**: extract the three elements pain point, action, benefit from copy / PRD / screenshot; confirm usage layout and ratio; list on-image copy item by item.
2. **Select template and defaults**: pick a composition from [layout-templates.md](references/layout-templates.md); settle characters, palette, typography hierarchy, material desensitization, and fact boundaries per [style-copy.md](references/style-copy.md).
3. **Assemble the prompt**: follow the order in [references/prompt-checklist.md](references/prompt-checklist.md); use `image_gen` for a new image, `image_edit` with the baseline image passed in for style/identity inheritance or localized changes.
4. **Produce and deliver**: show pure-image results to the user as they are generated; series images share character material, palette, and rounded-corner language.
5. **Local iteration**: recolor, reword, add/remove arrows, differentiate card tints, attach a logo, adjust whitespace, etc. Reuse the baseline in `image_edit` instead of redrawing the whole image.

## Reference Files

- [references/layout-templates.md](references/layout-templates.md): default ratios per usage and five composition templates with applicable scenarios.
- [references/style-copy.md](references/style-copy.md): personas and style tiers, color semantics, typography hierarchy, language rules, material desensitization, fact boundaries, and exclusions.
- [references/prompt-checklist.md](references/prompt-checklist.md): prompt assembly order, reference-image inheritance rules, and localized iteration actions.

## Assets

`assets/` holds historical baselines and finished series deliverables, used only as references for style, material, and rounded-corner language—not as identity masters to replicate:

- `baseline-clay-comic.jpg`: clay comic baseline (two stacked sections of three panels, pain point / benefit split).
- `clay-smart-ticket.jpg`: left-right comparison series deliverable (pain-point scene + smart-ticket interface card).
- `clay-group-chat-pain.jpg`: three-panel side-by-side pain-point series deliverable.

The brand logo is not bundled. When brand identity must be preserved, the user supplies the actual image per session and it is passed into `image_edit`.
