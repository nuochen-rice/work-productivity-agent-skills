# Lark Whiteboard Generator

Turn complex ideas into editable **Lark (Feishu) whiteboards** with a structured, hand-drawn infographic style.

This repository contains an AI agent skill plus a standalone SVG renderer. It is designed for international teams that want visual explanations that feel more human than a generic dashboard while remaining clear enough for product reviews, technical discussions, and executive communication.

## Preview

![Example structured sketch whiteboard](examples/overview-en.svg)

The preview is generated from [`examples/overview-en.json`](examples/overview-en.json) with the included Python renderer.

## What it does

- Follows the prompt language automatically: English in, English out; Chinese in, Chinese out.
- Supports explicitly requested bilingual boards.
- Creates overview maps, processes, journeys, cycles, roadmaps, role maps, comparisons, ecosystems, funnels, and pyramids.
- Produces SVG built from editable text, shapes, and connectors.
- Uses a consistent sketch-note visual system with a rigorous layout grid.
- Includes a dependency-free Python renderer for a reusable overview layout.
- Avoids fabricating missing facts, metrics, dates, or relationships.

## Example use cases

- “Map our product strategy as an editable Lark whiteboard.”
- “Turn this architecture description into a layered diagram.”
- “Visualize the customer onboarding journey.”
- “Create a roadmap from these milestones.”
- “Compare the current and target operating models.”
- “把这套项目协作机制整理成中文飞书画板。”

## Repository structure

```text
lark-whiteboard-gen/
├── SKILL.md                       # Agent instructions and routing logic
├── README.md                      # Public project documentation
├── LICENSE                        # MIT License
├── scripts/
│   └── render_whiteboard.py       # Standalone SVG renderer
├── references/
│   ├── layout-recipes.md          # Eight visual layout patterns
│   └── visual-style.md            # Color, typography, spacing, and line rules
└── examples/
    ├── overview-en.json           # English renderer input
    ├── overview-zh.json           # Chinese renderer input
    └── overview-en.svg            # Generated editable SVG example
```

## Quick start

Requirements:

- Python 3.9+
- No Python packages are required

Generate an SVG:

```bash
python3 scripts/render_whiteboard.py \
  --input examples/overview-en.json \
  --output examples/overview-en.svg
```

The renderer prints a JSON result containing the detected language, output path, and canvas dimensions.

## Input format

```json
{
  "language": "auto",
  "title": "Product launch operating model",
  "subtitle": "A shared framework from insight to learning",
  "focus": {
    "label": "One launch narrative",
    "value": "Aligned execution",
    "note": "Shared goals, owners, and evidence"
  },
  "groups": [
    {
      "title": "Market readiness",
      "icon": "◎",
      "items": ["Audience insight", "Positioning", "Channel plan"]
    },
    {
      "title": "Product readiness",
      "icon": "◇",
      "items": ["Release scope", "Quality gates", "Support plan"]
    },
    {
      "title": "Team readiness",
      "icon": "△",
      "items": ["Ownership", "Decision rhythm", "Escalation path"]
    }
  ],
  "steps_label": "Delivery path",
  "steps": ["Discover", "Frame", "Prepare", "Launch", "Learn"],
  "footer": "A launch is a coordinated system, not a single event"
}
```

The included renderer supports two to four groups, one to five items per group, and three to six steps. It renders input strings verbatim and does not perform translation.

## Using it as an agent skill

Copy the repository into the user-skill directory supported by your agent environment, or install it through that environment's skill management flow. The agent reads `SKILL.md`, chooses an appropriate visual skeleton, applies the references, and either:

1. generates a custom SVG or Mermaid diagram for the requested structure; or
2. uses the included renderer for the standard overview layout.

When Lark document and whiteboard integrations are available, the agent can place the result into a Lark document as an editable whiteboard. Without those integrations, the generated SVG remains a useful standalone artifact.

## Optional Lark compatibility check

If you use the public Lark whiteboard CLI, you can render and inspect the generated SVG:

```bash
npx -y @larksuite/whiteboard-cli@^0.2.13 \
  -i examples/overview-en.svg \
  -o examples/overview-en.png \
  -f svg

npx -y @larksuite/whiteboard-cli@^0.2.13 \
  -i examples/overview-en.svg \
  -f svg \
  --check
```

A production-ready board should have no serious text overflow, node overlap, or text occlusion.

## Design principles

- **One board, one focal point.**
- **Structure before decoration.**
- **One primary visual skeleton per canvas.**
- **Readable without a spoken walkthrough.**
- **Editable text instead of outlined glyphs.**
- **No invented facts for visual symmetry.**
- **Use charts for precise quantitative relationships.**

See [Visual System](references/visual-style.md) and [Layout Recipes](references/layout-recipes.md) for the full design guidance.

## Limitations

- The bundled Python script implements one reusable overview layout, not every diagram type.
- Lark publishing requires a host environment with suitable document and whiteboard integrations.
- The renderer does not translate copy; language adaptation is performed by the calling agent.
- Complex statistical visualizations should use a charting tool rather than a conceptual whiteboard.

## Contributing

Issues and pull requests are welcome. Useful contributions include new layout recipes, accessibility improvements, international typography tests, and additional renderer templates that preserve editability.

## License

Released under the [MIT License](LICENSE).
