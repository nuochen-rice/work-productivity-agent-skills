#!/usr/bin/env python3
"""Render an editable SVG for a structured sketch-style whiteboard.

The script is deliberately stdlib-only. It does not call Lark APIs; the caller
uses lark-doc/lark-whiteboard after validating the generated SVG.
"""

from __future__ import annotations

import argparse
import html
import json
import re
from pathlib import Path
from typing import Iterable

W, H = 1600, 1000
C = {
    "paper": "#FFFDF8",
    "ink": "#1F2329",
    "muted": "#646A73",
    "line": "#BBBFC4",
    "purple": "#5B5BD6",
    "purple_dark": "#292966",
    "purple_light": "#E8E8FF",
    "blue": "#245BDB",
    "blue_light": "#F0F4FC",
    "yellow": "#FEF1CE",
    "yellow_dark": "#8F5B00",
    "green": "#DFF5E5",
    "green_dark": "#237B4B",
}


def esc(value: object) -> str:
    return html.escape(str(value), quote=True)


def detect_language(payload: dict) -> str:
    explicit = str(payload.get("language", "auto")).lower()
    if explicit in {"zh", "en", "bilingual"}:
        return explicit
    blob = json.dumps(payload, ensure_ascii=False)
    return "zh" if re.search(r"[\u3400-\u9fff]", blob) else "en"


def units(text: str) -> float:
    total = 0.0
    for ch in text:
        if re.match(r"[\u3000-\u9fff\uff00-\uffef]", ch):
            total += 1.0
        elif ch.isspace():
            total += 0.35
        else:
            total += 0.58
    return total


def wrap(text: object, max_units: float, max_lines: int = 3) -> list[str]:
    raw = str(text or "").strip()
    if not raw:
        return []
    if "\n" in raw:
        parts = [p.strip() for p in raw.splitlines() if p.strip()]
    elif re.search(r"[\u3400-\u9fff]", raw):
        parts, current = [], ""
        for ch in raw:
            if current and units(current + ch) > max_units:
                parts.append(current)
                current = ch
            else:
                current += ch
        if current:
            parts.append(current)
    else:
        parts, current = [], ""
        for word in raw.split():
            trial = word if not current else f"{current} {word}"
            if current and units(trial) > max_units:
                parts.append(current)
                current = word
            else:
                current = trial
        if current:
            parts.append(current)
    if len(parts) > max_lines:
        parts = parts[:max_lines]
        last = parts[-1]
        parts[-1] = (last[:-1] + "…") if len(last) > 1 else "…"
    return parts


def text_block(x: float, y: float, text: object, size: int, *,
               color: str = C["ink"], weight: int = 400,
               anchor: str = "start", max_units: float = 36,
               max_lines: int = 3, line_height: float = 1.25) -> str:
    lines = wrap(text, max_units, max_lines)
    if not lines:
        return ""
    spans = []
    for idx, line in enumerate(lines):
        dy = 0 if idx == 0 else size * line_height
        spans.append(f'<tspan x="{x:.1f}" dy="{dy:.1f}">{esc(line)}</tspan>')
    return (
        f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" '
        f'font-weight="{weight}" fill="{color}" text-anchor="{anchor}">'
        + "".join(spans) + "</text>"
    )


def rounded_rect(x: float, y: float, w: float, h: float, fill: str,
                 stroke: str, sw: float = 3, r: float = 20) -> str:
    return (f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" '
            f'rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')


def arrow(x1: float, y1: float, x2: float, y2: float, color: str = C["line"]) -> str:
    mid = (y1 + y2) / 2
    return (
        f'<polyline points="{x1:.1f},{y1:.1f} {x1:.1f},{mid:.1f} {x2:.1f},{mid:.1f} '
        f'{x2:.1f},{y2:.1f}" fill="none" stroke="{color}" stroke-width="3"/>'
        f'<polygon points="{x2-7:.1f},{y2-10:.1f} {x2+7:.1f},{y2-10:.1f} {x2:.1f},{y2:.1f}" '
        f'fill="{color}"/>'
    )


def require(payload: dict, key: str) -> object:
    value = payload.get(key)
    if value in (None, "", []):
        raise ValueError(f"missing required field: {key}")
    return value


def render(payload: dict) -> str:
    require(payload, "title")
    focus = require(payload, "focus")
    groups = require(payload, "groups")
    steps = require(payload, "steps")
    if not isinstance(focus, dict):
        raise ValueError("focus must be an object")
    if not isinstance(groups, list) or not 2 <= len(groups) <= 4:
        raise ValueError("groups must contain 2 to 4 groups")
    if not isinstance(steps, list) or not 3 <= len(steps) <= 6:
        raise ValueError("steps must contain 3 to 6 steps")

    lang = detect_language(payload)
    title_size = 44 if lang == "zh" else 40
    parts: list[str] = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">',
        f'<rect x="0" y="0" width="{W}" height="{H}" fill="{C["paper"]}"/>',
        # restrained hand-drawn corner marks
        f'<path d="M64 104 L64 64 L104 64" fill="none" stroke="{C["ink"]}" stroke-width="4"/>',
        f'<path d="M1496 64 L1536 64 L1536 104" fill="none" stroke="{C["ink"]}" stroke-width="4"/>',
        text_block(80, 105, payload["title"], title_size, weight=700, max_units=42, max_lines=2),
        text_block(82, 148, payload.get("subtitle", ""), 17, color=C["muted"], max_units=88, max_lines=2),
        f'<path d="M82 167 C220 161 350 173 500 164" fill="none" stroke="{C["purple"]}" stroke-width="5"/>',
    ]

    # Central focus
    fx, fy, fw, fh = 470, 205, 660, 165
    parts += [
        rounded_rect(fx, fy, fw, fh, C["purple"], C["ink"], 4, 28),
        text_block(800, 255, focus.get("label", ""), 28, color="#FFFFFF", weight=700,
                   anchor="middle", max_units=28, max_lines=2),
        text_block(800, 310, focus.get("value", ""), 32, color="#FFFFFF", weight=700,
                   anchor="middle", max_units=22, max_lines=1),
        text_block(800, 345, focus.get("note", ""), 15, color="#FFFFFF",
                   anchor="middle", max_units=48, max_lines=1),
    ]

    # Supporting groups
    n = len(groups)
    gap = 28
    card_w = (W - 160 - gap * (n - 1)) / n
    card_y, card_h = 445, 285
    fills = [C["blue_light"], C["purple_light"], C["yellow"], C["green"]]
    strokes = [C["blue"], C["purple"], C["yellow_dark"], C["green_dark"]]
    for i, group in enumerate(groups):
        if not isinstance(group, dict):
            raise ValueError("each group must be an object")
        x = 80 + i * (card_w + gap)
        cx = x + card_w / 2
        parts.append(arrow(800, fy + fh, cx, card_y - 8, strokes[i]))
        parts.append(rounded_rect(x, card_y, card_w, card_h, fills[i], C["ink"], 3.2, 22))
        # small offset underline adds controlled sketch character
        parts.append(f'<path d="M{x+24:.1f} {card_y+72:.1f} C{x+card_w*0.35:.1f} {card_y+68:.1f} '
                     f'{x+card_w*0.7:.1f} {card_y+76:.1f} {x+card_w-24:.1f} {card_y+70:.1f}" '
                     f'fill="none" stroke="{strokes[i]}" stroke-width="4"/>')
        icon = group.get("icon") or str(i + 1)
        parts.append(text_block(x + 28, card_y + 45, icon, 25, color=strokes[i], weight=700,
                                max_units=4, max_lines=1))
        parts.append(text_block(x + 68, card_y + 44, group.get("title", ""), 22,
                                color=strokes[i], weight=700, max_units=20, max_lines=1))
        items = group.get("items") or []
        if not isinstance(items, list) or not 1 <= len(items) <= 5:
            raise ValueError("each group.items must contain 1 to 5 items")
        for j, item in enumerate(items):
            my = card_y + 112 + j * 46
            parts.append(f'<circle cx="{x+32:.1f}" cy="{my-6:.1f}" r="6" fill="{strokes[i]}"/>')
            parts.append(text_block(x + 50, my, item, 17, weight=500,
                                    max_units=max(15, card_w / 17), max_lines=2))

    # Reading path ribbon
    steps_y = 800
    default_steps_label = "阅读路径" if lang == "zh" else "Reading path"
    parts.append(text_block(80, 785, payload.get("steps_label", default_steps_label), 18,
                            color=C["muted"], weight=700, max_units=24, max_lines=1))
    step_gap = 18
    step_w = (W - 160 - step_gap * (len(steps) - 1)) / len(steps)
    for i, label in enumerate(steps):
        x = 80 + i * (step_w + step_gap)
        fill = C["purple_light"] if i % 2 else C["blue_light"]
        stroke = C["purple"] if i % 2 else C["blue"]
        parts.append(rounded_rect(x, steps_y, step_w, 92, fill, stroke, 2.5, 46))
        parts.append(text_block(x + step_w / 2, steps_y + 56, f"{i+1}. {label}", 18,
                                color=stroke, weight=700, anchor="middle",
                                max_units=max(10, step_w / 15), max_lines=2))
        if i < len(steps) - 1:
            ax = x + step_w + 3
            parts.append(f'<line x1="{ax:.1f}" y1="{steps_y+46}" x2="{ax+step_gap-6:.1f}" '
                         f'y2="{steps_y+46}" stroke="{C["ink"]}" stroke-width="3"/>')
            parts.append(f'<polygon points="{ax+step_gap-6:.1f},{steps_y+46} '
                         f'{ax+step_gap-15:.1f},{steps_y+39} {ax+step_gap-15:.1f},{steps_y+53}" '
                         f'fill="{C["ink"]}"/>')

    footer = payload.get("footer", "")
    if footer:
        parts += [
            rounded_rect(520, 925, 560, 48, C["yellow"], C["yellow_dark"], 2, 18),
            text_block(800, 956, footer, 15, color=C["yellow_dark"], weight=600,
                       anchor="middle", max_units=58, max_lines=1),
        ]
    parts.append("</svg>")
    return "\n".join(p for p in parts if p)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="Path to UTF-8 JSON input")
    parser.add_argument("--output", required=True, help="Path to output SVG")
    args = parser.parse_args()
    input_path = Path(args.input)
    output_path = Path(args.output)
    payload = json.loads(input_path.read_text(encoding="utf-8"))
    svg = render(payload)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(svg, encoding="utf-8")
    print(json.dumps({"ok": True, "language": detect_language(payload),
                      "output": str(output_path), "width": W, "height": H},
                     ensure_ascii=False))


if __name__ == "__main__":
    main()
