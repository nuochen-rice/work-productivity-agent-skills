# Visual System: Structured Sketch Infographics

## 1. Design goal

The canvas should feel like a professionally facilitated workshop board: approachable and hand-drawn, yet structured enough for a product review or executive presentation. Avoid both extremes—a generic web dashboard and unstructured doodling.

## 2. Palette

| Meaning | Fill | Stroke or text |
|---|---|---|
| Canvas | `#FFFDF8` | `#1F2329` |
| Primary focus | `#5B5BD6` | `#292966` or white text |
| Primary section | `#E8E8FF` | `#4E4EC8` |
| Information card | `#F0F4FC` | `#245BDB` |
| Key callout | `#FEF1CE` | `#8F5B00` |
| Positive state | `#DFF5E5` | `#237B4B` |
| Risk or blocker | `#FEE3E2` | `#C02C38` |
| Secondary line | none | `#BBBFC4` |
| Body text | none | `#1F2329` |
| Secondary text | none | `#646A73` |

Use blue and violet as the usual accents. Reserve yellow for takeaways and cautions, and red for genuine risk. When a brand palette is provided, use it as an accent rather than flooding the canvas.

## 3. Lines and shapes

- Use 3–4 px dark strokes for major containers and 2 px strokes for secondary cards.
- Prefer corner radii of 16, 20, or 24; use pill shapes for compact labels.
- Create restrained sketch character with short underline strokes, annotations, circles, or occasional slight offsets—not random distortion on every object.
- Use orthogonal connectors for primary paths. Every arrow must encode a real flow, dependency, or loop.
- Avoid shadows, complex gradients, and SVG features unsupported by the Lark parser.

## 4. Typography

- Rely on the whiteboard renderer's default sans-serif font; do not embed external fonts.
- Chinese title: 36–48; English title: 34–46; central idea: 26–34; section title: 18–24; body: 14–18; annotation: 12–14.
- English text often contains long words; allow roughly 12% more horizontal room.
- Estimate CJK at about 1 em per character and Latin at about 0.6 em. Add explicit line breaks rather than relying on browser wrapping.
- Keep a node to three lines when possible. Move long explanations into child nodes or annotation areas.

## 5. Grid and rhythm

- Use an 8-point spacing system: 8, 16, 24, 32, 48, and 64.
- Keep at least 64 px outer margin and 32 px between the title area and the diagram.
- Nodes at the same level should share dimensions. Inter-group spacing must exceed intra-group spacing.
- One element must be the largest, darkest, or otherwise strongest focal point.
- Make the reading path explicit with numbering, arrows, or spatial order; never require color alone to explain sequence.

## 6. Icons and decoration

- Use a small number of Unicode symbols or simple geometry for roles, phases, and object categories.
- Emoji may act as navigation markers but must not compete with the content.
- Limit each primary section to one icon.
- Sticky notes, circles, short underlines, and stars may highlight conclusions, but decoration should occupy less than roughly 10% of the canvas.

## 7. Language adaptation

- Keep the same information hierarchy across languages; do not add or remove conclusions merely because the language changes.
- Prefer concise English phrases in sentence case; avoid paragraphs in all caps.
- For bilingual output, place the primary language first and render the secondary language at about 85% size in a muted color.
- Language switching may change copy and container width, but never facts or relationships.

## 8. Anti-patterns

- A wall of identical rounded cards.
- One saturated color per section.
- Large dark backgrounds added only to look “technical.”
- Paragraphs squeezed into nodes.
- Invented content added for visual symmetry.
- Diagonal lines through nodes or arrows with no semantic purpose.
