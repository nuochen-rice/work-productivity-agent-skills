# Layout Recipes

## 1. Overview or layered framework

Use for product landscapes, capability maps, methodologies, business frameworks, knowledge structures, and project overviews.

Reading path: title → central idea or top-level goal → two to four supporting groups → steps, principles, or takeaway at the bottom.

The central idea must be the single visual focal point. Supporting groups explain or decompose it rather than competing with it.

## 2. Linear process or user journey

Use for business processes, approval flows, delivery pipelines, instructions, user journeys, and state transitions.

Default to left-to-right. Keep the primary path to five to eight steps. Name each node with a verb and an object. Label branch conditions and explain loops. When several roles participate, use three to six swimlanes rather than crossing many connectors.

## 3. Cycle or flywheel

Use for continuous improvement, growth loops, governance cycles, learning systems, and operating mechanisms.

Place three to six steps around one central outcome. Keep step labels grammatically parallel and arrows consistent. Add one or two inputs, outputs, or decision criteria around each step. Never invent steps just to complete a circle.

## 4. Timeline or roadmap

Use for releases, project milestones, event histories, and phased strategy.

Prefer a horizontal time axis and use one time granularity. Distinguish ordinary work, milestones, and the current point. Show uncertain plans with dashed or lighter styling and label confidence or `TBD`.

## 5. Role map or cross-team collaboration

Use for responsibilities, team collaboration, stakeholder maps, and system boundaries.

Choose columns, swimlanes, or a radial map:
- keep three to five responsibilities or concerns per role;
- emphasize the shared outcome separately;
- label relationships with verbs such as “provides,” “approves,” “depends on,” or “feeds back”;
- do not mix organizational hierarchy and process flow in one connector system.

## 6. Comparison or before/after

Use for before/after, option A/B, current/target, and competitor comparisons.

Compare the same dimensions on both sides, with the transition or decision in the center. Put the recommendation, applicability conditions, or success criteria in a separate bottom strip. Do not declare a winner without evidence.

## 7. Radial ecosystem or relationship map

Use for concept maps, knowledge graphs, stakeholders, product ecosystems, and dependency networks.

Make the center node largest. Limit first-level branches to seven. Cluster complex networks and label relationship lines whenever practical.

## 8. Funnel or pyramid

Use for staged filtering, segmentation, priority layers, and maturity models.

Keep three to five levels and express the same dimension on every level. If precise quantities or conversion rates dominate, use a data chart and reserve the whiteboard for the conceptual model and key takeaway.

## Renderer input

`scripts/render_whiteboard.py` supports a general “central idea + supporting groups + reading steps” overview:

```json
{
  "language": "auto",
  "title": "AI-native delivery model",
  "subtitle": "An end-to-end collaboration model from intake to learning",
  "focus": {
    "label": "Conversation as workspace",
    "value": "Natural-language orchestration",
    "note": "One entry point and one coordination layer"
  },
  "groups": [
    {
      "title": "Demand management",
      "icon": "✎",
      "items": ["Collect needs", "Set priorities", "Plan iterations"]
    },
    {
      "title": "Collaborative delivery",
      "icon": "✦",
      "items": ["Break down work", "Run agents", "Sync status"]
    },
    {
      "title": "Process assurance",
      "icon": "✓",
      "items": ["Detect risks", "Apply quality gates", "Escalate exceptions"]
    }
  ],
  "steps_label": "Reading path",
  "steps": ["Input", "Orchestrate", "Execute", "Validate", "Learn"],
  "footer": "Keep people and agents in one shared workflow"
}
```

Constraints:
- `language`: `auto`, `zh`, `en`, or `bilingual`; `auto` detects CJK characters in the payload.
- `groups`: two to four groups; each group contains one to five `items`.
- `steps`: three to six steps.
- Missing `icon` values fall back to sequence numbers; the renderer does not add unrelated emoji.
- All strings are rendered verbatim. The renderer does not translate; the calling agent prepares the target-language copy first.
- This renderer covers only the overview layout. Create purpose-built SVG or Mermaid for the other seven patterns.
