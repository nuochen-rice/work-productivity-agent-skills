---
name: lark-whiteboard-gen
description: Turn natural-language prompts, documents, or structured information into editable Lark (Feishu) whiteboards with a disciplined, hand-drawn infographic style. Automatically follows the user's language—Chinese prompts produce Chinese boards and English prompts produce English boards—and supports process maps, architecture diagrams, timelines, roadmaps, role relationships, collaboration models, feedback loops, comparisons, framework overviews, project plans, product explanations, and knowledge maps. Use when a user asks to visualize, map, diagram, or explain complex information on a Lark whiteboard.
author: chennuo.nuo
license: MIT
---

# Lark Whiteboard Generator

Transform complex information into an editable Lark (Feishu) whiteboard with a structured sketch-note aesthetic: conclusion-first storytelling, an obvious reading path, blue and violet accents, yellow callouts, bold dark outlines, and professional information hierarchy.

## Language behavior

1. Detect the primary language of the current request. Produce Simplified Chinese for Chinese prompts and English for English prompts.
2. For mixed-language prompts, follow the language carrying the core content. If still ambiguous, follow the last complete instruction.
3. Honor an explicitly requested language or bilingual output.
4. Preserve product names, proper nouns, APIs, code identifiers, and established acronyms verbatim unless the user asks for translation.
5. Produce a single-language board by default. For bilingual boards, place the primary language first and reduce copy density to protect readability.

## Workflow

### 1. Frame the communication goal

Identify:
- the single question the board must answer;
- the audience and presentation context;
- the one visual focal point;
- whether the information is sequential, hierarchical, temporal, grouped, cyclical, dependent, comparative, or radial;
- names, numbers, dates, and conclusions that must remain verbatim;
- whether the result should be a new document, a new board in an existing document, or an update to an existing board.

Do not invent facts or metrics. Structural editing and concise rewriting are allowed, but new assumptions must be labeled as assumptions, recommendations, or `TBD`.

### 2. Choose one primary visual skeleton

Select the layout by relationship type. Read [layout-recipes.md](references/layout-recipes.md) for the detailed patterns:
- overview or layered framework;
- linear process or user journey;
- cycle or flywheel;
- timeline or roadmap;
- role map or cross-team collaboration;
- comparison or before/after;
- radial ecosystem or relationship map;
- funnel or pyramid.

Use one primary skeleton per board. Express secondary relationships as local modules. Split boards above roughly 40 nodes unless the user explicitly requires a single canvas; in that case, enlarge the canvas and strengthen grouping rather than deleting important content.

### 3. Apply the visual system

Read [visual-style.md](references/visual-style.md) and keep color, line weight, typography, spacing, icons, and emphasis consistent. The target is structured hand-drawing on a rigorous grid—not random wobble, a wall of web-style cards, or decorative doodling.

### 4. Generate the source

Prefer SVG for custom composition and editable conversion. For a stable “central idea + supporting groups + reading steps” overview, use [render_whiteboard.py](scripts/render_whiteboard.py):

```bash
python3 scripts/render_whiteboard.py --input <input.json> --output <diagram.svg>
```

See [layout-recipes.md](references/layout-recipes.md) for the JSON schema. The script only generates SVG; it never calls Lark APIs.

Use Mermaid when it communicates a flow, sequence, or mind map more clearly. Continue with custom SVG for more expressive compositions. Never distort the content merely to fit the included renderer.

### 5. Deliver to Lark when integrations are available

Use the host environment's Lark document capability to create or update the document, and its Lark whiteboard capability to validate, preview, write, and export the diagram. Keep dependencies declarative: the included script must not call another skill's private tools or internal APIs.

- Default deliverable: one Lark document containing an editable whiteboard.
- For an existing document, insert the board at the requested location.
- Replacing a non-empty board rebuilds the entire board; obtain confirmation first.
- Use the current user's identity unless explicitly instructed otherwise.

If Lark integrations are unavailable, deliver the validated SVG source and explain that the caller can import or convert it separately.

### 6. Validate before delivery

Confirm all of the following:
- the board language follows the language rules;
- the reading path is understandable without verbal explanation;
- exactly one visual element is the strongest focal point;
- SVG copy uses `<text>` and `<tspan>` rather than paths;
- the SVG contains no `filter`, `mask`, `clipPath`, `pattern`, `foreignObject`, or scripts;
- there is no serious text overflow, node overlap, or connector collision;
- the preview is non-empty and the hierarchy is clear;
- after raw export, primary elements remain editable shapes, text, and connectors rather than one flattened image node;
- names, numbers, dates, relationships, and conclusions match the input;
- missing information has not been fabricated.

## Boundaries

- Use a data chart—not a conceptual whiteboard—for precise proportions, trends, distributions, or statistical comparisons.
- Choose a more appropriate artifact when the user only wants prose, a spreadsheet, or a standalone web page.
- When the user provides a brand system, follow it as far as possible without sacrificing editability and readability.
